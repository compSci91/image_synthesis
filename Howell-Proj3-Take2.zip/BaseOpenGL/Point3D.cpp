//
//  Point3D.cpp
//  BaseOpenGL
//
//  Created by Joshua Howell on 2/8/18.
//  Copyright © 2018 Joshua Howell. All rights reserved.
//

#include <stdio.h>
