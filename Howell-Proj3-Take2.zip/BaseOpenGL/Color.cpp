//
//  Color.cpp
//  BaseOpenGL
//
//  Created by Joshua Howell on 2/16/18.
//  Copyright © 2018 Joshua Howell. All rights reserved.
//

#include "Color.hpp"


